// AYONZ STORE — Product data
// Ubah harga/paket di sini saja. Modal pembayaran mengambil data ini secara dinamis.

const PRODUCTS = [
  {
    id: "holow",
    name: "Holow Execution",
    icon: "assets/holow.png",
    desc: "Akses eksekusi Holow, untuk kebutuhan basic sampai VIP.",
    badge: "DISCOUNT",
    plans: [
      {
        name: "1 Bulan Basic",
        oldPrice: 20000,
        price: 11000,
      },
      {
        name: "Permanen Basic",
        oldPrice: 40000,
        price: 22000,
      },
      {
        name: "Permanen VIP",
        oldPrice: 50000,
        price: 28000,
      },
    ],
  },
  {
    id: "voltage",
    name: "Voltage Death",
    icon: "assets/voltage.png",
    desc: "Membership Voltage Death, mulai dari harian sampai permanen.",
    badge: null,
    plans: [
      {
        name: "Member 1 Hari",
        oldPrice: null,
        price: 3000,
      },
      {
        name: "Member 1 Bulan",
        oldPrice: null,
        price: 10000,
      },
      {
        name: "Member Permanen",
        oldPrice: null,
        price: 15000,
      },
    ],
  },
  {
    id: "megumin",
    name: "Megumin Crasher",
    icon: "assets/megumin.png",
    desc: "Paket Megumin Crasher, dari harian sampai role Owner.",
    badge: null,
    plans: [
      {
        name: "1 Hari",
        oldPrice: 3000,
        price: 2000,
        saveLabel: "Hemat Rp1.000",
      },
      {
        name: "1 Minggu",
        oldPrice: null,
        price: 10000,
      },
      {
        name: "1 Bulan",
        oldPrice: 25000,
        price: 20000,
        saveLabel: "Hemat Rp5.000",
      },
      {
        name: "Member",
        oldPrice: null,
        price: 25000,
      },
      {
        name: "VIP",
        oldPrice: null,
        price: 30000,
      },
      {
        name: "Reseller",
        oldPrice: null,
        price: 40000,
      },
      {
        name: "Admin",
        oldPrice: null,
        price: 50000,
      },
      {
        name: "Owner",
        oldPrice: null,
        price: 75000,
      },
    ],
  },
];

// Format angka ke Rupiah, contoh: 11000 -> "Rp11.000"
function formatRupiah(amount) {
  return "Rp" + amount.toLocaleString("id-ID");
}

const TELEGRAM_ADMIN_URL = "https://t.me/yueech";
const TELEGRAM_CHANNEL_URL = "https://t.me/yuechh";
const WHATSAPP_URL = "https://wa.me/6283165194089";
const QRIS_DONATION_URL = "https://saweria.co/Ayonzzy1";
