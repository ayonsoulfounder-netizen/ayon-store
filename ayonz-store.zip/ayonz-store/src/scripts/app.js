(function () {
  "use strict";

  /* ============================================================
     Render product cards
     ============================================================ */

  const grid = document.getElementById("products-grid");

  function planRowHTML(product, plan, planIndex) {
    const hasDiscount = plan.oldPrice != null;
    const saveLabel = plan.saveLabel || null;

    return `
      <div class="plan-row">
        <div class="plan-row__info">
          <span class="plan-row__name">${plan.name}</span>
          ${saveLabel ? `<span class="plan-row__save">${saveLabel}</span>` : ""}
        </div>
        <div class="plan-row__price">
          ${hasDiscount ? `<span class="plan-row__old">${formatRupiah(plan.oldPrice)}</span>` : ""}
          <span class="plan-row__now ${hasDiscount ? "plan-row__now--promo" : ""}">${formatRupiah(plan.price)}</span>
        </div>
        <button
          type="button"
          class="plan-row__buy"
          data-product-id="${product.id}"
          data-plan-index="${planIndex}"
          aria-label="Beli ${product.name} paket ${plan.name} seharga ${formatRupiah(plan.price)}"
        >+</button>
      </div>
    `;
  }

  function productCardHTML(product) {
    return `
      <article class="product-card reveal">
        <div class="product-card__head">
          <img
            class="product-card__icon"
            src="${product.icon}"
            alt="Icon ${product.name}"
            width="56" height="56"
            loading="lazy"
            decoding="async"
          />
          <h3 class="product-card__name">${product.name}</h3>
          ${product.badge ? `<span class="product-card__badge">${product.badge}</span>` : ""}
        </div>
        <p class="product-card__desc">${product.desc}</p>
        <div class="product-card__plans">
          ${product.plans.map((plan, i) => planRowHTML(product, plan, i)).join("")}
        </div>
      </article>
    `;
  }

  function renderProducts() {
    if (!grid) return;
    grid.innerHTML = PRODUCTS.map(productCardHTML).join("");
  }

  renderProducts();

  /* ============================================================
     Payment Modal
     ============================================================ */

  const overlay = document.getElementById("payment-modal-overlay");
  const modal = document.getElementById("payment-modal");
  const closeBtn = document.getElementById("payment-modal-close");
  const confirmBtn = document.getElementById("payment-confirm-btn");

  const fieldProduct = document.getElementById("order-product");
  const fieldPlan = document.getElementById("order-plan");
  const fieldTotal = document.getElementById("order-total");

  let lastFocusedEl = null;
  let currentOrder = null;

  function openModal(product, plan) {
    currentOrder = { product, plan };

    fieldProduct.textContent = product.name;
    fieldPlan.textContent = plan.name;
    fieldTotal.textContent = formatRupiah(plan.price);

    lastFocusedEl = document.activeElement;

    overlay.classList.add("is-open");
    document.body.classList.add("modal-open");
    overlay.setAttribute("aria-hidden", "false");

    // Move focus into modal
    window.setTimeout(() => {
      closeBtn.focus();
    }, 50);
  }

  function closeModal() {
    overlay.classList.remove("is-open");
    document.body.classList.remove("modal-open");
    overlay.setAttribute("aria-hidden", "true");
    currentOrder = null;

    if (lastFocusedEl && typeof lastFocusedEl.focus === "function") {
      lastFocusedEl.focus();
    }
  }

  // Delegate clicks on dynamically-rendered buy buttons
  document.addEventListener("click", (e) => {
    const buyBtn = e.target.closest(".plan-row__buy");
    if (!buyBtn) return;

    const productId = buyBtn.getAttribute("data-product-id");
    const planIndex = Number(buyBtn.getAttribute("data-plan-index"));
    const product = PRODUCTS.find((p) => p.id === productId);
    if (!product) return;
    const plan = product.plans[planIndex];
    if (!plan) return;

    openModal(product, plan);
  });

  closeBtn.addEventListener("click", closeModal);

  overlay.addEventListener("click", (e) => {
    if (e.target === overlay) closeModal();
  });

  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape" && overlay.classList.contains("is-open")) {
      closeModal();
    }

    // Simple focus trap while modal open
    if (e.key === "Tab" && overlay.classList.contains("is-open")) {
      const focusable = modal.querySelectorAll(
        'button, a[href], [tabindex]:not([tabindex="-1"])'
      );
      if (focusable.length === 0) return;
      const first = focusable[0];
      const last = focusable[focusable.length - 1];

      if (e.shiftKey && document.activeElement === first) {
        e.preventDefault();
        last.focus();
      } else if (!e.shiftKey && document.activeElement === last) {
        e.preventDefault();
        first.focus();
      }
    }
  });

  confirmBtn.addEventListener("click", () => {
    if (!currentOrder) return;
    const { product, plan } = currentOrder;

    const message =
      `Halo Admin Ayonz Store.\n\n` +
      `Saya sudah melakukan pembayaran.\n\n` +
      `Produk: ${product.name}\n` +
      `Paket: ${plan.name}\n` +
      `Total: ${formatRupiah(plan.price)}\n\n` +
      `Saya akan mengirimkan bukti transfer di chat ini.`;

    const url = `${TELEGRAM_ADMIN_URL}?text=${encodeURIComponent(message)}`;
    window.open(url, "_blank", "noopener");
  });

  /* ============================================================
     Donation button -> reuse payment modal with fixed "order"
     ============================================================ */

  const donateBtn = document.getElementById("donate-btn");
  if (donateBtn) {
    donateBtn.addEventListener("click", () => {
      openModal(
        { id: "donation", name: "Support Megumin Crasher" },
        { name: "Donasi Sukarela", price: 0 }
      );
      // Donation total is voluntary — hide the numeric total, show a friendly label
      fieldTotal.textContent = "Sukarela";
    });
  }

  /* ============================================================
     Mobile navbar
     ============================================================ */

  const burger = document.getElementById("navbar-burger");
  const mobileMenu = document.getElementById("navbar-mobile-menu");

  if (burger && mobileMenu) {
    burger.addEventListener("click", () => {
      const isOpen = mobileMenu.classList.toggle("is-open");
      burger.setAttribute("aria-expanded", String(isOpen));
    });

    mobileMenu.querySelectorAll("a").forEach((link) => {
      link.addEventListener("click", () => {
        mobileMenu.classList.remove("is-open");
        burger.setAttribute("aria-expanded", "false");
      });
    });
  }

  /* ============================================================
     Music Player
     ============================================================ */

  const audio = document.getElementById("bg-audio");
  const playToggle = document.getElementById("music-toggle");
  const muteToggle = document.getElementById("music-mute");
  const progressBar = document.getElementById("music-progress-bar");

  let isPlaying = false;
  let isMuted = false;

  function updatePlayIcon() {
    playToggle.textContent = isPlaying ? "❚❚" : "▶";
    playToggle.setAttribute(
      "aria-label",
      isPlaying ? "Jeda musik" : "Putar musik"
    );
  }

  function updateMuteIcon() {
    muteToggle.textContent = isMuted ? "🔇" : "🔊";
    muteToggle.setAttribute(
      "aria-label",
      isMuted ? "Nyalakan suara" : "Bisukan suara"
    );
  }

  if (audio && playToggle) {
    playToggle.addEventListener("click", () => {
      if (isPlaying) {
        audio.pause();
        isPlaying = false;
      } else {
        audio.play().then(() => {
          isPlaying = true;
          updatePlayIcon();
        }).catch(() => {
          // Autoplay-style rejection; user can try again
          isPlaying = false;
          updatePlayIcon();
        });
        return;
      }
      updatePlayIcon();
    });

    muteToggle.addEventListener("click", () => {
      isMuted = !isMuted;
      audio.muted = isMuted;
      updateMuteIcon();
    });

    audio.addEventListener("timeupdate", () => {
      if (!audio.duration) return;
      const pct = (audio.currentTime / audio.duration) * 100;
      progressBar.style.width = pct + "%";
    });

    audio.addEventListener("ended", () => {
      isPlaying = false;
      updatePlayIcon();
      progressBar.style.width = "0%";
    });
  }

  /* ============================================================
     Scroll reveal (IntersectionObserver, lightweight)
     ============================================================ */

  const revealTargets = () => document.querySelectorAll(".reveal, .product-card");

  if ("IntersectionObserver" in window) {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("is-visible");
            observer.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.12, rootMargin: "0px 0px -40px 0px" }
    );

    // Observe static reveal elements immediately
    document.querySelectorAll(".reveal").forEach((el) => observer.observe(el));
    // Observe dynamically rendered product cards
    document.querySelectorAll(".product-card").forEach((el) => observer.observe(el));
  } else {
    // Fallback: no IO support, just show everything
    revealTargets().forEach((el) => el.classList.add("is-visible"));
  }
})();
